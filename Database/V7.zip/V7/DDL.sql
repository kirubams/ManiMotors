Alter table InvoiceMargin
Add InvoiceDate Date